"""Watch a YouTube Live chat's message speed and cut a short clip on demand.

This never records the stream: only the chat is read (a few bytes a second), so a stream can be watched for hours
without downloading the video. When someone presses a clip button, ffmpeg fetches just that many seconds from the
live stream's short DVR window and the normal Soham's Clipper renderer makes the clip with captions.

The chat-spike numbers follow the same mechanism as NeonClipper: 10-second buckets, a rolling baseline of up to
five minutes, and a spike when a bucket is well above that baseline. The level bar is the last 30 seconds of
messages scaled against the usual rate, so it is meaningful from the first seconds of a stream.
"""
import collections
import json
import math
import re
import statistics
import subprocess
import threading
import time
import urllib.parse
import uuid
from pathlib import Path

from . import brain, config, ctx, fetch_model, jobs, media, render, roman, safe, transcribe

BUCKET = 10          # seconds per chat bucket
HISTORY = 30         # buckets in the baseline (5 minutes)
SIGMA = 2.5          # a spike is above the mean by this many standard deviations
RATIO = 2.5          # ...and at least this many times the mean
MIN_MSGS = 8         # ...with at least this many messages in the bucket
COOLDOWN = 45        # seconds between two suggested spikes
SESSIONS: dict = {}  # session id -> Session (one per browser tab)
SESS_LOCK = threading.Lock()

_YT_ID = re.compile(r"(?:v=|/live/|youtu\.be/|/shorts/)([A-Za-z0-9_-]{11})")


def clean_name(name: str) -> str:
    """Clip folder names come from URLs, so keep them to the shape we generate (no path tricks)."""
    if not re.fullmatch(r"live-\d{10,16}-\d{1,3}s", name or ""):
        raise ValueError("That clip is not here.")
    return name


def video_id(url: str) -> str:
    m = _YT_ID.search(str(url or ""))
    if not m:
        raise ValueError("Paste a YouTube live video link (youtube.com/watch?v=… or youtube.com/live/…).")
    return m.group(1)


def hype_percent(msgs30: int, baseline_bucket: float, hist_n: int) -> int:
    """0-100 level for the bar. Before there is enough history, 150 messages in 30 seconds is full scale;
    afterwards, four times the usual chat rate is full scale."""
    if hist_n < 3:
        return int(max(0, min(100, round(100.0 * msgs30 / 150.0))))
    usual30 = max(baseline_bucket * 3.0, 6.0)
    return int(max(0, min(100, round(100.0 * msgs30 / (4.0 * usual30)))))


def hype_label(h: int) -> str:
    return "quiet" if h < 25 else "building momentum" if h < 50 else "hot" if h < 80 else "peak viral hype"


def is_spike(count: int, history: list) -> bool:
    if len([h for h in history if h]) < 6:
        return False
    mu, sd = statistics.mean(history), statistics.pstdev(history) or 1.0
    return count >= MIN_MSGS and count > mu + SIGMA * sd and count >= RATIO * max(mu, 1.0)


class Session:
    """One watched live stream. Chat counting and clipping run on background threads; the browser only polls state."""

    def __init__(self, url: str, opts: dict | None = None):
        self.vid = video_id(url)
        self.url = f"https://www.youtube.com/watch?v={self.vid}"
        o = opts if isinstance(opts, dict) else {}
        self.id = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8]
        self.dir = config.user_dir(ctx.uid()) / "live_hype" / self.id
        self.dir.mkdir(parents=True, exist_ok=True)
        self.lang = o.get("lang", "en") if fetch_model.known(o.get("lang", "")) else "en"
        self.layout = o.get("layout", "blur") if o.get("layout") in render.LAYOUTS else "blur"
        self.style = o.get("style", "bounce") if o.get("style") in render.STYLES else "bounce"
        # Captions need a big speech model and slow everything down, so live clips are kept fast by default.
        self.captions = bool(o.get("captions", False))
        self.before = int(o.get("before", 0)) or 20     # how far before the press the clip starts: set per cut
        self.counts = collections.Counter()
        self.stop_ev = threading.Event()
        self.stream = None                              # resolved stream URL, reused for every clip (fast)
        self.stream_lock = threading.Lock()
        self.active = 0                                 # number of clips being made (not a limit: many can run)
        self.user = ctx.uid()
        self.state = {"id": self.id, "video": self.vid, "url": self.url, "status": "starting",
                      "stage": "Connecting to chat", "hype": 0, "hype_label": "quiet", "msgs30": 0,
                      "baseline": 0.0, "hist_n": 0, "spikes": 0, "elapsed": 0, "chat": "connecting",
                      "title": "", "clips": [], "error": None, "captions": self.captions,
                       "lang": self.lang, "layout": self.layout, "style": self.style}

    def public(self) -> dict:
        return dict(self.state)

    def start(self):
        with SESS_LOCK:
            active = [s for s in SESSIONS.values() if s.state["status"] in ("starting", "watching")
                      and not s.stop_ev.is_set()]
            if active:
                raise ValueError("A live stream is already being watched. Stop it first.")
            SESSIONS[self.id] = self
        threading.Thread(target=ctx.bind(self._chat), daemon=True).start()
        threading.Thread(target=ctx.bind(self._loop), daemon=True).start()

    def stop(self):
        self.stop_ev.set()
        self.state["status"] = "stopped"
        self.state["stage"] = "Stopped"
        with SESS_LOCK:
            SESSIONS.pop(self.id, None)

    # ---------------------------------------------------------------- chat (no video is fetched here)
    def _chat(self):
        try:
            import pytchat
        except ImportError:
            self.state["chat"] = "pytchat is not installed on this machine"
            return
        while not self.stop_ev.is_set():
            try:
                chat = pytchat.create(video_id=self.vid, interruptable=False)
                self.state["chat"] = "connected"
                while chat.is_alive() and not self.stop_ev.is_set():
                    for item in chat.get().sync_items():
                        self.counts[int(time.time() // BUCKET)] += 1
                    time.sleep(0.5)
            except Exception as e:  # noqa: BLE001 - chat can drop at any time; just reconnect
                if self.stop_ev.is_set():
                    return
                self.state["chat"] = "reconnecting"
            if self.stop_ev.wait(3):
                return

    def _loop(self):
        t0 = time.time()
        last_bucket, last_spike = None, -1e9
        self.state["status"] = "watching"
        self.state["stage"] = "Watching chat"
        while not self.stop_ev.wait(1):
            now = time.time()
            cur = int(now // BUCKET)
            m30 = sum(self.counts.get(b, 0) for b in (cur - 2, cur - 1, cur))
            h = hype_percent(m30, self.state["baseline"], self.state["hist_n"])
            self.state.update(elapsed=int(now - t0), msgs30=m30, hype=h, hype_label=hype_label(h))
            done = cur - 1
            if done != last_bucket:
                last_bucket = done
                first = int(t0 // BUCKET)
                hist = [self.counts.get(b, 0) for b in range(max(first, done - HISTORY), done)]
                self.state["hist_n"] = len(hist)
                self.state["baseline"] = round(statistics.mean(hist), 1) if hist else 0.0
                if is_spike(self.counts.get(done, 0), hist) and now - last_spike > COOLDOWN:
                    last_spike = now
                    self.state["spikes"] += 1
                    self.state["stage"] = f"Chat spike · {self.counts.get(done, 0)} messages in 10 s (usual {self.state['baseline']})"

    # ---------------------------------------------------------------- on-demand clipping
    def clip(self, seconds: int, after: int = 0):
        """Start a cut of the last `seconds` seconds. Returns at once; many clips can be made at the same time."""
        seconds = max(5, min(60, int(seconds)))
        if self.state["status"] not in ("watching", "starting"):
            raise ValueError("This live session has ended.")
        name = f"live-{int(time.time() * 1000)}-{seconds}s"
        card = {"id": name, "seconds": seconds, "status": "running", "stage": "Fetching the live segment",
                "title": "", "why": "You pressed Clip now", "file": "", "error": ""}
        self.state["clips"].insert(0, card)
        self.active += 1
        threading.Thread(target=ctx.bind(self._cut), args=(seconds, after, name, card), daemon=True).start()
        return seconds

    def _job_id(self, name: str) -> str:
        return f"lh-{self.id}-{name}"

    def _clip_record(self, name: str):
        job = jobs.get(self._job_id(name))
        return (job, next((c for c in job["clips"] if c["id"] == name), None)) if job else (None, None)

    def _register(self, name: str, clip: dict, words: list, info: dict, seconds: int, src: Path):
        """Put the finished live clip into the normal library. From here on it is an ordinary Soham's Clipper clip:
        it appears under All videos, re-renders through the real job worker, and posts through /api/posts."""
        jid, d = self._job_id(name), self.dir / name
        now = time.time()
        rec = dict(clip, id=name, status="done", version=1, made_at=now, src=str(src), score=0,
                   description="", hashtags=[], posts={})
        job = {"id": jid, "user": ctx.uid(), "kind": "video", "creator": None, "dir": str(d),
               "created": now, "source": {"type": "file", "name": f"YouTube Live · {self.vid}", "path": str(src)},
               "source_path": str(src), "options": dict(jobs.DEFAULTS), "status": "done", "stage": "Done",
               "progress": 1.0, "title": f"YouTube Live · {self.vid}", "uploader": "",
               "duration": info["duration"], "clips": [rec], "error": None, "ai": {},
               "width": info["width"], "height": info["height"]}
        with jobs._lock:
            jobs._jobs[jid] = job
            jobs._by_user.setdefault(ctx.uid(), {})[jid] = job
        (d / "words.json").write_text(json.dumps(words, indent=1), encoding="utf-8")
        (d / "clips" / f"{name}.json").write_text(json.dumps(
            {k: rec.get(k) for k in ("title", "description", "hashtags", "hook", "start", "end", "score")},
            indent=1), encoding="utf-8")
        jobs.save(job)

    def _cut(self, seconds: int, after: int, name: str, card: dict):
        clip_dir = self.dir / name
        src = clip_dir / "source.mp4"
        try:
            clip_dir.mkdir(parents=True, exist_ok=True)
            stream = self._stream()                      # resolve once, reuse for every clip
            fetch_segment(stream, seconds + after, src)
            card["stage"] = "Cutting the clip"
            info = media.probe(src)
            words = []
            if self.captions:                            # off by default: captions need a big model and are slow
                try:
                    wav = clip_dir / "audio.wav"
                    media.extract_audio(src, wav)
                    audio = media.load_audio(wav)
                    fetch_model.ensure(self.lang, start=self.lang == fetch_model.DEFAULT)
                    words = transcribe.transcribe(audio, lang=self.lang)
                    if self.lang.startswith(("hi", "ur")):
                        words = roman.words(words)
                except Exception:  # noqa: BLE001 - a clip without captions still gets made
                    words = []
            clip = {"id": name, "start": 0.0, "end": min(seconds, info["duration"]), "style": self.style,
                    "layout": self.layout, "captions": bool(words), "hook": "LIVE MOMENT",
                    "title": (self.state.get("title") or "Live moment")[:70], "highlight_words": []}
            if self.layout == "gameplay":
                try:
                    f = __import__("studio.facecam", fromlist=["detect"]).detect(src)
                    if f and f.get("conf") == "high":
                        clip["facecam"] = [f["x"], f["y"], f["w"], f["h"]]
                except Exception:
                    pass
                if not clip.get("facecam"):
                    clip["layout"] = "crop"
            out = render.render_clip(src, clip_dir / "clips", name, clip, words, info["width"], info["height"])
            clip.update(out)
            self._register(name, clip, words, info, seconds, src)
            self._save(name, {"clip": clip, "words": words, "width": info["width"], "height": info["height"],
                              "seconds": seconds, "facecam": clip.get("facecam"), "gameplay_box": clip.get("gameplay_box")})
            card.update(status="done", stage="Done", file=f"/live-hype/{self.id}/{name}/clip.mp4",
                        cover=f"/live-hype/{self.id}/{name}/clip.jpg", editable=True, job=self._job_id(name))
        except Exception as e:  # noqa: BLE001
            card.update(status="error", stage="Couldn't make that clip", error=safe.friendly(e, 200))
        finally:
            self.active -= 1

    # ---------------------------------------------------------------- editing + posting
    def _settings_path(self, name: str) -> Path:
        return self.dir / name / "settings.json"

    def _save(self, name: str, data: dict):
        self._settings_path(name).write_text(json.dumps(data, indent=1), encoding="utf-8")

    def settings(self, name: str) -> dict:
        """Everything the editor needs, with the real job clip as the source of truth after an Apply."""
        clean_name(name)
        p = self._settings_path(name)
        if not p.is_file():
            raise ValueError("That clip isn't ready to edit yet.")
        s = json.loads(p.read_text(encoding="utf-8"))
        job, rec = self._clip_record(name)
        clip = rec or s["clip"]

        def norm(box):
            if not box or len(box) != 4:
                return None
            v = [float(x) for x in box]
            if all(0 <= x <= 1.001 for x in v):
                return [round(x, 4) for x in v]
            return [round(v[0] / s["width"], 4), round(v[1] / s["height"], 4),
                    round(v[2] / s["width"], 4), round(v[3] / s["height"], 4)]

        return {"id": name, "job": self._job_id(name), "video": f"/media/{self._job_id(name)}/{name}.mp4",
                "source": f"/live-hype/{self.id}/{name}/source.mp4",
                "clip": f"/live-hype/{self.id}/{name}/clip.mp4",
                "cover": f"/live-hype/{self.id}/{name}/clip.jpg",
                "width": s["width"], "height": s["height"], "seconds": s["seconds"],
                "layout": clip.get("layout", "blur"), "style": clip.get("style", "bounce"),
                "split": render._split_fraction(clip.get("split")),
                "facecam": norm(clip.get("facecam")), "gameplay_box": norm(clip.get("gameplay_box")),
                "title": clip.get("title") or "Live moment", "hook": clip.get("hook") or "LIVE MOMENT",
                "status": rec.get("status", "done") if rec else "done",
                "version": rec.get("version", 1) if rec else 1,
                "posts": list((rec.get("posts") or {}).values()) if rec else []}

    def preview(self, name: str, changes: dict) -> dict:
        """One rendered frame of the current layout/boxes/split, for live feedback in the editor. This never
        touches the real clip — Apply is still what writes the finished video into the library."""
        clean_name(name)
        p = self._settings_path(name)
        if not p.is_file():
            raise ValueError("That clip isn't ready to edit yet.")
        s = json.loads(p.read_text(encoding="utf-8"))
        job, rec = self._clip_record(name)
        clip = dict(rec or s["clip"])
        changes = changes or {}
        layout = str(changes.get("layout") or clip.get("layout") or "blur")
        if layout not in render.LAYOUTS:
            raise ValueError("Unknown layout.")
        clip["layout"] = layout
        clip["split"] = render._split_fraction(changes.get("split", clip.get("split")))
        for key in ("facecam", "gameplay_box"):
            if key in changes:
                box = jobs.clean_box(changes[key])
                clip[key] = box
        try:                                     # preview the frame the user is looking at in the editor
            at = max(0.0, min(float(changes.get("at", 2.0)), max(0.1, float(s["seconds"]) - 0.1)))
        except (TypeError, ValueError):
            at = 2.0
        src = self.dir / name / "source.mp4"
        out = self.dir / name / "preview.jpg"
        render.preview_frame(src, out, clip, s["width"], s["height"], at)
        return {"url": f"/live-hype/{self.id}/{name}/preview.jpg?v={int(time.time() * 1000)}"}

    def apply(self, name: str, changes: dict) -> dict:
        """Re-cut through Soham's Clipper's real render worker, so the result appears everywhere a normal clip does."""
        clean_name(name)
        job, rec = self._clip_record(name)
        if not job or not rec:
            raise ValueError("That clip isn't in your library yet. Start watching again to edit it.")
        # A fresh Apply simply replaces whatever render is pending. Soham's Clipper's render worker takes one clip at a
        # time, so a quick second click never errors — the last set of boxes wins when it gets to the front.
        jobs.request_render(job["id"], name, changes or {})
        for card in self.state["clips"]:
            if card.get("id") == name:
                card["stage"] = "Applying your changes…"
        return self.settings(name)

    def post(self, name: str, opts: dict) -> dict:
        """Queue the finished clip on the normal posting worker, exactly like posting from All videos."""
        clean_name(name)
        job, rec = self._clip_record(name)
        if not job or not rec:
            raise ValueError("That clip isn't in your library yet. Start watching again to post it.")
        if rec.get("status") != "done":
            raise ValueError("Wait until Apply finishes before posting.")
        o = opts or {}
        account_ids = [str(a) for a in (o.get("accounts") or [])][:20]
        if not account_ids:
            raise ValueError("Pick an account first.")
        rec["title"] = str(o.get("title") or rec.get("title") or "Live moment")[:100]
        rec["description"] = str(o.get("description") or "")[:2000]
        rec["hashtags"] = jobs.clean_hashtags(o.get("hashtags") or [])
        jobs.save(job)
        from . import posting
        made = posting.enqueue(job, rec, account_ids, now=bool(o.get("now")))
        if not made:
            raise ValueError("Nothing was queued. Pick an account this clip hasn't gone to already.")
        return {"queued": len(made), "posts": list((rec.get("posts") or {}).values())}

    def _stream(self) -> dict:
        """The live stream's HLS URL, resolved once for the session so every clip fetch is instant."""
        with self.stream_lock:
            if self.stream is None:
                self.stream = resolve_stream(self.url)
            return self.stream


def resolve_stream(url: str) -> dict:
    """Ask yt-dlp once for the live HLS URLs. Cached for the whole session so each clip skips this slow step."""
    from yt_dlp import YoutubeDL
    opts = {"quiet": True, "no_warnings": True, "noplaylist": True, "skip_download": True}
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise ValueError("That stream isn't available right now.")
    all_fmts = [f for f in (info.get("formats") or []) if f.get("url")]
    if not all_fmts:
        raise ValueError("That stream isn't available right now.")
    muxed = [f for f in all_fmts if f.get("vcodec") != "none" and f.get("acodec") != "none"]
    videos = [f for f in all_fmts if f.get("vcodec") != "none" and f.get("acodec") == "none"]
    audios = [f for f in all_fmts if f.get("vcodec") == "none" and f.get("acodec") != "none"]
    # HLS is preferred because it lets ffmpeg seek inside the live window. Pick the sharpest one — the first
    # entry in yt-dlp's list is often a 144p preview, which makes the finished clip look terrible.
    def pick(fs):
        hls = [f for f in fs if f.get("protocol") == "m3u8" or ".m3u8" in f.get("url", "")]
        pool = hls or fs
        return max(pool, key=lambda f: (f.get("height") or 0, f.get("tbr") or 0, f.get("filesize") or 0)) if pool else None
    vf, af = pick(muxed), None
    if not vf:
        vf, af = pick(videos), pick(audios)
    if not vf:
        raise ValueError("This stream has no usable picture. Try a different link.")
    return {"video": vf, "audio": af}


def fetch_segment(stream: dict, seconds: int, dest: Path) -> None:
    """Fetch only the last `seconds` of a live stream, copying the compressed data (no re-encode) so it is fast."""
    vf, af = stream["video"], stream.get("audio")
    vin = _input(vf, seconds)
    cmd = ["ffmpeg", "-y", "-v", "error"] + vin
    map_a = "0:a:0"
    if af:
        cmd += _input(af, seconds)
        map_a = "1:a:0"
    cmd += ["-t", str(seconds), "-map", "0:v:0", "-map", map_a,
            "-c", "copy", "-movflags", "+faststart", str(dest)]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
    if p.returncode or not dest.exists() or dest.stat().st_size < 10000:
        # Some streams can't be stream-copied into mp4 (codec or timestamp trouble). Re-encode just the audio,
        # keeping the video copy, then try a full encode as a last resort.
        cmd2 = ["ffmpeg", "-y", "-v", "error"] + vin
        if af:
            cmd2 += _input(af, seconds)
        cmd2 += ["-t", str(seconds), "-map", "0:v:0", "-map", map_a,
                 "-c:v", "copy", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dest)]
        p2 = subprocess.run(cmd2, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
        if p2.returncode or not dest.exists() or dest.stat().st_size < 10000:
            raise RuntimeError("Couldn't fetch that part of the stream. " + safe.friendly(p2.stderr[-400:] or "no data", 200))


def _input(fmt: dict, seconds: int) -> list:
    """ffmpeg input arguments for one HLS/progressive stream, seeking back into the live DVR window."""
    url = fmt["url"]
    args = []
    headers = fmt.get("http_headers") or {}
    if headers:
        args += ["-headers", "".join(f"{k}: {v}\r\n" for k, v in headers.items())]
    if "m3u8" in url:
        back = _hls_segments_back(url, headers, seconds)
        if back:
            args += ["-live_start_index", str(-back)]
    return args + ["-i", url]


def _hls_segments_back(url: str, headers: dict, seconds: int) -> int:
    """How many segments to skip back from the live edge to cover `seconds`. 0 if the playlist can't be read."""
    import httpx
    try:
        r = httpx.get(url, headers=headers, timeout=20)
        r.raise_for_status()
        lines = [l.strip() for l in r.text.splitlines() if l.strip()]
        if any(l.startswith("#EXT-X-STREAM-INF") for l in lines):
            variants = [lines[i + 1] for i, l in enumerate(lines) if l.startswith("#EXT-X-STREAM-INF") and i + 1 < len(lines)]
            if variants:
                return _hls_segments_back(urllib.parse.urljoin(url, variants[0]), headers, seconds)
        durs = [float(l.split(":", 1)[1].rstrip(",")) for l in lines if l.startswith("#EXTINF:")]
        if not durs:
            return 0
        total, n = 0.0, 0
        for d in reversed(durs):
            total += d
            n += 1
            if total >= seconds + 2:
                break
        return n
    except Exception:  # noqa: BLE001 - an unreadable playlist still lets ffmpeg try from the live edge
        return 0


def mine(sid: str) -> Session:
    s = SESSIONS.get(sid)
    if not s or s.user != ctx.uid():
        return None
    return s
