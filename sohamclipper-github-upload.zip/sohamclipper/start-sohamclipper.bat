@echo off
cd /d "%~dp0"
start "" "%~dp0.venv\Scripts\python.exe" -m studio.server
timeout /t 3 /nobreak >nul
start "" http://127.0.0.1:8765
